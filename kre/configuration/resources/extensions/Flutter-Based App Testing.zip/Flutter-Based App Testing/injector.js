{
  let script = document.createElement('script');
  script.src = chrome.runtime.getURL('flutter-based-app-testing.js');
  (document.head || document.documentElement).appendChild(script);
}
